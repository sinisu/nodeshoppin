const Product = require("../models/Product");

const productController = {}

productController.createProduct = async(req,res) =>{
    try{
        const {sku,name,size,image,category,description,price,stock,status} = req.body;
        const product = new Product({sku,name,size,image,category,description,price,stock,status});
        await product.save();
        res.status(200).json({status:"success",product});
    }catch(error){
        res.status(400).json({status:"fail",error:error.message});
    }
;}

productController.getProducts = async(req,res) => {
    try{
        const {page,name} = req.query;
        const cond = name?{name:{$regex:name,$options:'i'}}:{};
        let query = Product.find(cond);
        const productList = await query.exec(); // query의 선언과 exec로 실행을 따로 함

        // 아래 방식은 조건이 늘어날 때 마다 구문을 새로 써야 하므로 비효율적
        // if(name){
        //     const product = await Product.find({name:{
        //         $regex:name, // name을 포함한 정보를 검색
        //         $option:"i" // 대문자, 소문자 구분하지 않겠다는 뜻
        //     }});
        // }else{
        //     const products = await Product.find({});
        // }
        res.status(200).json({status:"success",data:productList});
    }catch(error){
        res.status(400).json({status:"fail",error:error.message});
    };
}

module.exports = productController;